import org.jsoup.Jsoup;
//import java.io.IOException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String [ ] args)
    {

        try {


            Scanner scanner = new Scanner(System.in);
            DBConnection mainDB = new DBConnection();

            boolean isRunning = true;
            int choice = 0;
            //---------------
            //new EscThread(scanner);   //THREAD Handling Error !!!
            //---------------
            while(isRunning) {

                //new EscThread();
                //Thread t1 = new Thread(new EscThread());
                //t1.start();

                System.out.print(
                        "\n=========================\n"+
                        "||         Menu        ||\n"+
                        "=========================\n"+
                        "1. View saved URLs\n"+
                        "2. Insert URL\n"+
                        "3. Delete URL\n"+
                        "4. Edit URL\n"+
                        "5. Enter Keywords to search in URLs. Search Results will be saved in Database\n"+
                        "6. Exit Application\n"+
                        "7. View Keyword Searches in URLs and Negative-Positive impressions\n"+
                        "8. Export Results to csv Files\n"+
                        "9. Insert Negative Term\n"+
                        "10.Delete Negative Term\n"+
                        "11.Insert Positive Term\n"+
                        "12.Delete Positive Term\n"+
                        "13.View Negative-Positive terms\n"+
                        "=========================\n"+
                        "Please choose an option :\n"
                );
                //int choice = scanner.nextInt();
                //int choice = 0;
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt();
                }
                else{
                    System.out.println("Please give an integer!! ");
                    scanner.next(); //System.out.println(scanner.next());
                    // scanner.reset();
                    continue;
                }

                switch (choice) {
                    case 1:
                        // Perform "original number" case.
                        /**
                         * Made a new Class DBConnection. So here we make a new object
                         * And return all the result of the querry
                         */

                        mainDB.printAllUrls();
                        break;
                    case 2:
                        // Perform "encrypt number" case.
                        System.out.println("Enter URL:");
                        //Scanner urlScan = new Scanner(System.in);
                        //String url = urlScan.next();
                        String url;
                        if(scanner.hasNext()){
                            url = scanner.next();
                        }
                        else{
                            System.out.println("Not a valid URL!!! Return to main menu.");
                            scanner.nextLine();
                            break;
                        }

                        System.out.println("Rows inserted : " + mainDB.insertUrl(url));
                        //urlScan.close();
                        break;
                    case 3:
                        //DBConnection mainDB = new DBConnection();
                        int urlId;
                        System.out.println("Available URLs:");
                        mainDB.printAllUrls();
                        System.out.println("Please select the ID of the URL you wish to delete:");
                        if (scanner.hasNextInt()){
                            urlId = scanner.nextInt();
                        }
                        else{
                            System.out.println("Not a valid number!!! Return to main menu.");
                            scanner.next();
                            break;
                        }

                        System.out.println("Rows deleted : " + mainDB.deleteUrlbyID(urlId));

                        break;
                    case 4:
                        //DBConnection mainDB = new DBConnection();
                        int urlId4; String newURL;
                        System.out.println("Available URLs:");
                        mainDB.printAllUrls();
                        System.out.println("Please select the ID of the URL you wish to edit:");
                        if (scanner.hasNextInt()){
                            urlId4 = scanner.nextInt();
                        }
                        else{
                            System.out.println("Not a valid number!!! Return to main menu.");
                            scanner.next();
                            break;
                        }

                        System.out.println("Please give the new URL:");
                        /*String urlout = mainDB.selectUrlbyID(urlId4);
                        System.out.println(urlout);*/
                        //System.out.println(mainDB.selectUrlbyID(urlId4));

                        if (scanner.hasNext()){
                            newURL = scanner.next();
                        }
                        else{
                            System.out.println("Not a valid URL!!! Return to main menu.");
                            scanner.next();
                            break;
                        }
                        System.out.println("Rows edited : " + mainDB.editUrlbyID(urlId4,newURL));

                        break;
                    case 5:
                        //Read the number of keywords
                        System.out.println("Enter the Number of keywords for search");
                            //Not use a new scanner. //Scanner keyScan = new Scanner(System.in);
                        Integer numKey;
                        if (scanner.hasNextInt()){
                            numKey = scanner.nextInt();
                        }
                        else{
                            System.out.println("Not a valid number!!! Return to main menu.");
                            scanner.nextLine();
                            break;
                        }
                        //Read the keywords
                        ArrayList<String> keyArrayList = new ArrayList<String>();
                        System.out.println("Enter the keywords that you will search");
                        //Read keywords from the User
                        for(int i=1;i<=numKey;i++){
                            System.out.println("Enter keyword "+ i+" : ");
                            keyArrayList.add(scanner.next());

                        }
                        //Check Array List content
                        for (String arr:keyArrayList) {
                            System.out.println("keyword \""+arr+"\" was entered");
                        }
                        //Select an URL to search the user's keywords. Deprecated!!!



                        //DBConnection db3= new DBConnection();
                        ArrayList<String> urlsArrayList = mainDB.selectAllUrls();
                        String stringHtml;

                        //Check URLs ArrayList
                        System.out.println("============All URLs to be searched=============");
                        for (String testUrl:urlsArrayList) {
                            System.out.println(testUrl);
                        }
                        System.out.println("================================================");

                        ArrayList<Thread> threadsList= new ArrayList<Thread>(); //ArrayList which stores all the threads that search keywords in URLs.
                            int i = 0; //i = 1;

                            for (String selectedUrl : urlsArrayList) {
                                threadsList.add(new Thread(new IMThread(String.valueOf(i),selectedUrl,keyArrayList)));  //Create new thread that will search all the keywords in a URL.
                                threadsList.get(i).start(); //Start the execution of the new thread
                                /* new IMThread(String.valueOf(i),selectedUrl,keyArrayList); */
                                i++;

                            }


                        break;
                    case 6:
                        //System.exit(0);
                        System.out.println("---Exiting---");
                        isRunning = false;
                        break;
                    case 7:
                        //DBConnection mainDB = new DBConnection();
                        mainDB.selectAllResults();
                        mainDB.selectNegativeImpressions();
                        mainDB.selectPositiveImpressions();
                        break;
                    case 8:
                        ExportResults exportResults = new ExportResults();
                        exportResults.exportKeywordsFile();
                        exportResults.exportNegativeFile();
                        exportResults.exportPositiveFile();
                        //System.out.println("File exported successfully.");
                        break;
                    case 9:
                        System.out.println("Enter Negative term:");

                        String nterm;
                        if(scanner.hasNext()){
                            nterm = scanner.next();
                        }
                        else{
                            System.out.println("Not a valid term!!! Return to main menu.");
                            scanner.nextLine();
                            break;
                        }


                        mainDB.insertNegativeTerm(nterm);
                        //urlScan.close();
                        break;
                    case 10:

                        int nId;
                        System.out.println("Available Negative terms:");
                        mainDB.selectNegativeTerms();
                        System.out.println("Please select the ID of the Negative term you wish to delete:");
                        if (scanner.hasNextInt()){
                            nId = scanner.nextInt();
                        }
                        else{
                            System.out.println("Not a valid Id!!! Return to main menu.");
                            scanner.next();
                            break;
                        }

                        System.out.println("Rows deleted : " + mainDB.deleteNegativebyID(nId));

                        break;
                    case 11:
                        System.out.println("Enter Positive term:");

                        String pterm;
                        if(scanner.hasNext()){
                            pterm = scanner.next();
                        }
                        else{
                            System.out.println("Not a valid term!!! Return to main menu.");
                            scanner.nextLine();
                            break;
                        }


                        mainDB.insertPositiveTerm(pterm);
                        //urlScan.close();
                        break;
                    case 12:

                        int pId;
                        System.out.println("Available Positive terms:");
                        mainDB.selectPositiveTerms();
                        System.out.println("Please select the ID of the Positive term you wish to delete:");
                        if (scanner.hasNextInt()){
                            pId = scanner.nextInt();
                        }
                        else{
                            System.out.println("Not a valid Id!!! Return to main menu.");
                            scanner.next();
                            break;
                        }

                        System.out.println("Rows deleted : " + mainDB.deletePositivebyID(pId));

                        break;
                    case 13:

                        mainDB.selectNegativeTerms();
                        mainDB.selectPositiveTerms();
                        break;
                    case 19:
                        /*---------Test Area---------*/
                        String urlDummy = "https://www.efsyn.gr";
                        String dummyText;
                        ArrayList<IMThread> threadList= new ArrayList<IMThread>();  //Array with Threads

                        try {
                            //System.out.println(Jsoup.connect(urlDummy).get());
                            System.out.println(Jsoup.connect(urlDummy).get().text());   //Returns greek text from the website !!!
                            //System.out.println(Jsoup.connect(urlDummy).get().html());
                            dummyText = Jsoup.connect(urlDummy).get().text();
                            String strSplit = dummyText.substring(522,622);
                            System.out.println(strSplit);

                            String strArray[] = strSplit.split(" ",20);
                            for(String ind : strArray) {
                                System.out.print(ind+"|");
                            }
                            System.out.println();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        // The user input an unexpected choice.
                        System.out.println("Please choose an option between 1 - 13. Please try again");
                        //scanner.nextLine();

                }

            }
            scanner.close();

        }
        catch(IllegalArgumentException a){
            System.out.println(a.getMessage());
            System.out.println(a.toString());

        }
        /*catch(HttpStatusException e){
            System.out.println(e.getUrl());
            System.out.println(e.getStatusCode());

        }
        catch(IOException e){
            e.printStackTrace();
        }
        */

    }


}
