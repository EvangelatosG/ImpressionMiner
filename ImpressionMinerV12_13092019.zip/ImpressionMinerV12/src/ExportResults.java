import java.io.FileWriter;
import java.sql.*;

public class ExportResults {

    public void exportKeywordsFile(){
        /**
         * Write to a file
         */
        FileWriter fileWriter ;
        try {
            fileWriter = new FileWriter("Keywords-Results.csv");


            String url = "jdbc:sqlite:database/ImpresionMiner.db";
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(url);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            String query = "select * from keywords";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            fileWriter.append("id");
            fileWriter.append(';');
            fileWriter.append("url");
            fileWriter.append(';');
            fileWriter.append("keyword");
            fileWriter.append(';');
            fileWriter.append("count");
            fileWriter.append(';');
            fileWriter.append("Date");
            fileWriter.append('\n');
            while (rs.next()) {
                fileWriter.append(rs.getString(1));
                fileWriter.append(';');
                fileWriter.append(rs.getString(2));
                fileWriter.append(';');
                fileWriter.append(rs.getString(3));
                fileWriter.append(';');
                fileWriter.append(rs.getString(4));
                fileWriter.append(';');
                fileWriter.append(rs.getString(5));
                fileWriter.append(';');
                fileWriter.append('\n');
            }
            fileWriter.flush();
            fileWriter.close();
            conn.close();
            System.out.println("============================================");
            System.out.println("SUCCESS: CSV File was created successfully.");
            System.out.println("============================================");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void exportNegativeFile(){
        /**
         * Write to a file
         */
        FileWriter fileWriter ;
        try {
            fileWriter = new FileWriter("Negative-Results.csv");


            String url = "jdbc:sqlite:database/ImpresionMiner.db";
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(url);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            String query = "select * from negativeimpressions";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            fileWriter.append("id");
            fileWriter.append(';');
            fileWriter.append("url");
            fileWriter.append(';');
            fileWriter.append("keyword");
            fileWriter.append(';');
            fileWriter.append("term");
            fileWriter.append(';');
            fileWriter.append("Date");
            fileWriter.append('\n');
            while (rs.next()) {
                fileWriter.append(rs.getString(1));
                fileWriter.append(';');
                fileWriter.append(rs.getString(2));
                fileWriter.append(';');
                fileWriter.append(rs.getString(3));
                fileWriter.append(';');
                fileWriter.append(rs.getString(4));
                //System.out.println(rs.getString(4));    //Test
                fileWriter.append(';');
                fileWriter.append(rs.getString(5));
                fileWriter.append(';');
                fileWriter.append('\n');

            }
            fileWriter.flush();
            fileWriter.close();
            conn.close();
            System.out.println("============================================");
            System.out.println("SUCCESS: CSV File was created successfully.");
            System.out.println("============================================");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void exportPositiveFile(){
        /**
         * Write to a file
         */
        FileWriter fileWriter ;
        try {
            fileWriter = new FileWriter("Positive-Results.csv");


            String url = "jdbc:sqlite:database/ImpresionMiner.db";
            Connection conn = null;
            try {
                conn = DriverManager.getConnection(url);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            String query = "select * from positiveimpressions";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            fileWriter.append("id");
            fileWriter.append(';');
            fileWriter.append("url");
            fileWriter.append(';');
            fileWriter.append("keyword");
            fileWriter.append(';');
            fileWriter.append("term");
            fileWriter.append(';');
            fileWriter.append("Date");
            fileWriter.append('\n');
            while (rs.next()) {
                fileWriter.append(rs.getString(1));
                fileWriter.append(';');
                fileWriter.append(rs.getString(2));
                fileWriter.append(';');
                fileWriter.append(rs.getString(3));
                fileWriter.append(';');
                fileWriter.append(rs.getString(4));
                fileWriter.append(';');
                fileWriter.append(rs.getString(5));
                fileWriter.append(';');
                fileWriter.append('\n');
            }
            fileWriter.flush();
            fileWriter.close();
            conn.close();
            System.out.println("============================================");
            System.out.println("SUCCESS: CSV File was created successfully.");
            System.out.println("============================================");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
