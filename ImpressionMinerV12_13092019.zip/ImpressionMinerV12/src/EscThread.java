import java.util.Scanner;

public class EscThread implements Runnable {

    Scanner inputReader;
    //qScanner inputReader = new Scanner(System.in);

    public EscThread(Scanner scan){
        inputReader = scan;
        Thread t = new Thread(this);
        t.start();
    };

    public void run() {
        //Scanner inputReader = new Scanner(System.in);

        while (true) {
            if (inputReader.hasNext()) {
                String input = inputReader.next();
                /*
                if (input.equals("["))
                {
                    rand+=100;
                    System.out.println("Pressed [");
                }
                if (input.equals("]"))
                {
                    rand-=100;
                    System.out.println("Pressed ]");
                }
                */

                if (input.equals("q")) { //input.equalsIgnoreCase("Q"
                    System.out.println("Escape Thread !!! " + input);
                    continue;
                    //break; // stop KeyPressThread
                }
                else
                {
                    System.out.println(input);
                }
            }
        }

    }
}
