import org.jsoup.Jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.CASE_INSENSITIVE;

public class IMThread implements Runnable{
    private String name;
    /* private Thread t; */
    private String selectedUrl;
    private ArrayList<String> keyArrayList;

    //Constructor
    public IMThread(String threadName, String url, ArrayList<String> keys){
        this.name = threadName;
        this.selectedUrl = url;
        this.keyArrayList = keys;
        /*t = new Thread(this,name);
        t.start();*/

}

//Run method of the Thread
    public void run() {
        System.out.println(Thread.currentThread().getName());   //Print thread name.
        DBConnection db4 = new DBConnection();
        String stringHtml;
        try {
            //Search the URL for the keywords
            stringHtml = Jsoup.connect(selectedUrl).get().text();   //stringHtml = Jsoup.connect(selectedUrl).get().html();
        } catch (IllegalArgumentException e) {
            /*System.out.println("\n==================================================");
            System.out.println(e.getMessage());
            System.out.println("==================================================");*/
            //System.out.println("Not valid URL : "+selectedUrl);
            return;
        } catch (IOException e) {
           /* System.out.println("\n==================================================");
            System.out.println("URL: " + selectedUrl + ".\t" + e.getMessage());
            System.out.println("==================================================");*/
            return;
        }

        int k = 0;
        int count = 0;
        String impressionsStr;  // String with 100 characters search for positive-negative impressions .
        //String[] impressionsArray;  //String Array that will store the impressions

        //Regular expressions

        for (String keyword : keyArrayList) {
            Pattern ptrn = Pattern.compile(keyword, CASE_INSENSITIVE); // Pattern ptrn = Pattern.compile(keyword);
            Matcher mtchr = ptrn.matcher(stringHtml);

            while (mtchr.find(k)) { //Resets this matcher and then attempts to find the next subsequence of the input sequence that matches the pattern, starting at the specified index.
                count++;    //System.out.print(count + "  ");
                k = mtchr.start() + 1;  //Returns the start index of the previous match(start()).

                //Call the function for good and bad impressions HERE !!!
                if(k > 50 && stringHtml.length() > k+50){
                    impressionsStr = stringHtml.substring(k-50,k+50);
                }
                else if(k < 50 && stringHtml.length() > k+50){
                    impressionsStr = stringHtml.substring(0,k+50);
                }
                else if(k > 50 && stringHtml.length() < k+50){
                    impressionsStr = stringHtml.substring(k-50, stringHtml.length() );
                }
                else{
                    impressionsStr = stringHtml.substring(0, stringHtml.length() );
                }

                db4.searchImpressions(selectedUrl,keyword,impressionsStr);
                //impressionsArray = impressionsStr.split(" ",10);


            }

            //insertDBKeyword.insertKeyword(keyword, count);
            db4.insertKeyword(selectedUrl, keyword, count);
            k = 0;
            count = 0;

        }

    }
}
