import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class DBConnection {
    /**
     * Connect to the test.db database
     * @return the Connection object
     */
    private Connection conn;

    private void connect() {
        // SQLite connection string
        String url = "jdbc:sqlite:database/ImpresionMiner.db";
        conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        //return conn;
    }

    private void disconnect(){
        try{
            if(!conn.isClosed())
                conn.close();
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }

    /**
     * select all rows in the warehouses table
     */
    public void printAllUrls(){
        String sql = "SELECT id, url FROM urls";

        try {
             this.connect();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql);

            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t" +
                        rs.getString("url"));
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }


    public int insertUrl(String url) {
        String sql = "INSERT INTO urls(url) VALUES(?)";
        int rowsAffected;
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, url);
            rowsAffected = pstmt.executeUpdate();
            this.disconnect();
            return rowsAffected;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }
    }

    public void insertNegativeTerm(String term) {
        String sql = "INSERT INTO negativeterms(term) VALUES(?)";
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, term);
            pstmt.executeUpdate();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insertPositiveTerm(String term) {
        String sql = "INSERT INTO positiveterms(term) VALUES(?)";
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, term);
            pstmt.executeUpdate();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectAllResults(){
        String sql = "SELECT id,url,keyword,shown,timestamp FROM keywords";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);

            System.out.println("\nKeywords shown in URLs");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tShown\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("url")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("keyword")    + "\t\t\t\t" +
                        "\t\t" +rs.getInt("shown")         + "\t\t\t\t" +
                        "\t\t" +rs.getString("timestamp")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectNegativeImpressions(){
        String sql = "SELECT id,url,keyword,term,timestamp FROM negativeimpressions";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nNegative Impressions in Keyword searches");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tTerm\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("url")    + "\t\t\t\t"	 +
                        "\t\t" +rs.getString("keyword")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("term")         + "\t\t\t\t" +
                        "\t\t" +rs.getString("timestamp")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectPositiveImpressions(){
        String sql = "SELECT id,url,keyword,term,timestamp FROM positiveimpressions";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nPositive Impressions in Keyword searches");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tTerm\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("url")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("keyword")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("term")         + "\t\t\t\t" +
                        "\t\t" +rs.getString("timestamp")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectNegativeTerms(){
        String sql = "SELECT id,term FROM negativeterms";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nNegative Terms");
            System.out.println("========================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tTerm\t\t\t\t");
            System.out.println("========================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("term")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectPositiveTerms(){
        String sql = "SELECT id,term FROM positiveterms";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nPositive Terms");
            System.out.println("========================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tTerm\t\t\t\t");
            System.out.println("========================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("term")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insertKeyword(String url,String keyword,int shown){
        String sql = "INSERT INTO keywords(url,keyword,shown,timestamp) VALUES(?,?,?,?)";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String ts = sdf.format(timestamp);


        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, url);
            pstmt.setString(2, keyword);
            pstmt.setInt(3, shown);
            pstmt.setString(4, ts);
            pstmt.executeUpdate();

            pstmt.close();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public String selectUrlbyID(int id){
        String sql = "SELECT url FROM urls WHERE id=?";

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            ResultSet rs = pstmt.executeQuery();

           // pstmt.close();
            //rs.close();
            //conn.close();

            if (!rs.next()){
                //this.disconnect();
                return null;
            }
            else {
                //this.disconnect();
                return rs.getString(1);
            }


        } catch (SQLException e) {
            System.out.println(e.getMessage());
            //this.disconnect();
            return null;
        }

    }

    public int deleteUrlbyID(int id){
        String sql = "DELETE FROM urls WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int deleteNegativebyID(int id){
        String sql = "DELETE FROM negativeterms WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int deletePositivebyID(int id){
        String sql = "DELETE FROM positiveterms WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int editUrlbyID(int id,String URL){
        String sql = "UPDATE urls SET url=? WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1,URL);
            pstmt.setInt(2,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public void searchImpressions(String url,String keyword,String extStr){
        String impressionsArray[] = extStr.split(" ",10);   //Split the String into an array of strings seperated from blanks.

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String ts = sdf.format(timestamp);  //Make timestamp

        //Queries
        String sql = "SELECT term FROM positiveterms ";
        String sql2 = "INSERT INTO positiveimpressions(url,keyword,term,timestamp) VALUES(?,?,?,?)";
        String sql3 = "SELECT term FROM negativeterms ";
        String sql4 = "INSERT INTO negativeimpressions(url,keyword,term,timestamp) VALUES(?,?,?,?)";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
           /* System.out.println("==============================================================");
            System.out.println("ID\t\t|\t\tURL\t\t|\t\tKeyword\t\t|\t\tShown\t\t|\t\tDate");
            System.out.println("==============================================================");*/
            // loop through the result set
            while (rs.next()) {
                for(String token : impressionsArray){
                    if(token.equalsIgnoreCase(rs.getString("term"))){
                        PreparedStatement pstmt = conn.prepareStatement(sql2);
                        pstmt.setString(1, url);
                        pstmt.setString(2, keyword);
                        pstmt.setString(3, token);
                        pstmt.setString(4, ts);
                        pstmt.executeUpdate();
                    }
                }

            }

            Statement stmt2  = conn.createStatement();
            ResultSet rs2    = stmt2.executeQuery(sql3);

            while (rs2.next()) {
                for(String token : impressionsArray){
                    if(token.equalsIgnoreCase(rs2.getString("term"))){
                        PreparedStatement pstmt2 = conn.prepareStatement(sql4);
                        pstmt2.setString(1, url);
                        pstmt2.setString(2, keyword);
                        pstmt2.setString(3, token);
                        pstmt2.setString(4, ts);
                        pstmt2.executeUpdate();
                    }
                }

            }

            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public ArrayList<String> selectAllUrls(){

        ArrayList<String> urls = new ArrayList<String>();
        String sql = "SELECT url FROM urls";
        int i=0;

        try {
            this.connect();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql);

            while (rs.next()) {
                urls.add(rs.getString("url"));
                //urls[i] = rs.getString("url");

            }
            this.disconnect();
            return urls;
        }
     catch (SQLException e) {
        System.out.println(e.getMessage());
        return null;
    }

    }


}

