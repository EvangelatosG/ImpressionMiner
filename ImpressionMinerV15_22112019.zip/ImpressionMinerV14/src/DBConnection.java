import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

//import static java.sql.Statement.RETURN_GENERATED_KEYS;


public class DBConnection {
    /**
     * Connect to the test.db database
     * @return the Connection object
     */
    private Connection conn ; // static --> Few inserts work in choice 5 .
    //private static Connection conn = DriverManager.getConnection("jdbc:sqlite:database/ImpresionMiner.db");
   /* private Lock dbLock = new ReentrantLock(); // ReentrantLock implements the Lock interface
    private Lock dbLock2 = new ReentrantLock();*/

    /*private static ReentrantLock lock1 = new ReentrantLock();
    private static ReentrantLock lock2 = new ReentrantLock();
*/
/*******************************************************************/
/****************    Singleton Design Pattern    *******************/
/*******************************************************************/
    private static DBConnection instance = null;

    private DBConnection()
    {
        // private constructor
    }

    //synchronized method to control simultaneous access
    public synchronized static DBConnection getInstance()   //synchronized
    {
        if (instance == null)
        {
            // if instance is null, initialize
            instance = new DBConnection();
        }
        return instance;
    }
/******************************************************************/
/******************************************************************/

    private void connect() {
        // SQLite connection string
        String url = "jdbc:sqlite:database/ImpresionMiner.db";
        //conn = null;
        try {
            //if(conn == null)
                conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        //return conn;
    }

    private void disconnect(){
        try{
            //if(!conn.isClosed())
                conn.close();
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }



    public void printAllUrls(){
        String sql = "SELECT id, url FROM urls";

        try {
             this.connect();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql);

            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t" +
                        rs.getString("url"));
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }


    public int insertUrl(String url) {
        String sql = "INSERT INTO urls(url) VALUES(?)";
        int rowsAffected;
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, url);
            rowsAffected = pstmt.executeUpdate();
            this.disconnect();
            return rowsAffected;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }
    }

    public void insertNegativeTerm(String term) {
        String sql = "INSERT INTO negativeterms(term) VALUES(?)";
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, term);
            pstmt.executeUpdate();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insertPositiveTerm(String term) {
        String sql = "INSERT INTO positiveterms(term) VALUES(?)";
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, term);
            pstmt.executeUpdate();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    //Old selectAllResults() that prints data from one table.


    public void selectAllResults(){
        String sql = "SELECT k.id, u.url, k.keyword, k.shown, k.timestamp FROM keywords AS k INNER JOIN urls AS u ON k.url_id = u.id;";   //"SELECT id,url,keyword,shown,timestamp FROM keywords";
        String sql2 = "SELECT t.term FROM negativeimpressions AS i INNER JOIN negativeterms AS t ON i.term_id = t.id WHERE i.keywords_id = ? ;";
        String sql3 = "SELECT t.term FROM positiveimpressions AS i INNER JOIN positiveterms AS t ON i.term_id = t.id WHERE i.keywords_id = ? ;";

        try {
            this.connect();

            PreparedStatement pstmt  = conn.prepareStatement(sql);
            //pstmt.setInt(1,id);
            ResultSet rs    = pstmt.executeQuery();

            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            ResultSet rs2;    //= pstmt2.executeQuery();
            PreparedStatement pstmt3 = conn.prepareStatement(sql3);
            ResultSet rs3;

            //Statement stmt  = conn.createStatement();
            //ResultSet rs    = pstmt.executeQuery(sql);
            int keywordsId;
           /* System.out.println("\nKeywords shown in URLs");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tShown\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");*/
            // loop through the result set
            while (rs.next()) {
                keywordsId = rs.getInt(1);
                System.out.println("ID: "+ keywordsId +" ,URL: " + rs.getString(2) + " ,Keyword: " +  rs.getString(3) +
                        " ,Times shown: " + rs.getInt(4) +" ,Timestamp: " + rs.getString(5) );

                pstmt2.setInt(1,keywordsId);
                rs2 = pstmt2.executeQuery();
                if(rs2 != null) {
                    System.out.print("Negative Terms: ");
                    while (rs2.next()) {
                        System.out.print(rs2.getString(1) + "\t");

                    }
                    rs2.close();
                }else{
                    System.out.println("No Negative terms found");
                }
                System.out.println();
                pstmt3.setInt(1,keywordsId);
                rs3 = pstmt3.executeQuery();
                if(rs3 != null) {
                    System.out.print("Positive Terms: ");
                    while (rs3.next()) {
                        System.out.print(rs3.getString(1) + "\t");

                    }
                    rs3.close();
                }else{
                    System.out.println("No Positive terms found");
                }

                System.out.println();
                /*rs.getString("k.keyword")
                        rs.getInt("k.shown")
                        rs.getString("k.timestamp")  */


            }

            rs.close();

            pstmt.close();
            pstmt2.close();
            pstmt3.close();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectAllResultsByDate(String firstDate,String secondDate){
        String sql = "SELECT k.id, u.url, k.keyword, k.shown, k.timestamp FROM keywords AS k INNER JOIN urls AS u ON k.url_id = u.id " +
                "WHERE date(k.timestamp) BETWEEN ? AND ? ;";   //"SELECT id,url,keyword,shown,timestamp FROM keywords";
        String sql2 = "SELECT t.term FROM negativeimpressions AS i INNER JOIN negativeterms AS t ON i.term_id = t.id WHERE i.keywords_id = ? ;";
        String sql3 = "SELECT t.term FROM positiveimpressions AS i INNER JOIN positiveterms AS t ON i.term_id = t.id WHERE i.keywords_id = ? ;";

        //firstDate = ;
        try {
            this.connect();

            PreparedStatement pstmt  = conn.prepareStatement(sql);
            //pstmt.setDate(1,firstDate);
           /* System.out.println("\'"+firstDate+"\'");
            System.out.println("\'"+secondDate+"\'");*/
            pstmt.setString(1,firstDate);
            pstmt.setString(2,secondDate);
            ResultSet rs    = pstmt.executeQuery();

            /*if(!rs.next()) {
                System.out.println("No Keywords were found between those dates.");
                return;
            }*/


            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            ResultSet rs2;    //= pstmt2.executeQuery();
            PreparedStatement pstmt3 = conn.prepareStatement(sql3);
            ResultSet rs3;

            //Statement stmt  = conn.createStatement();
            //ResultSet rs    = pstmt.executeQuery(sql);
            boolean hasRows = false;
            int keywordsId;
           /* System.out.println("\nKeywords shown in URLs");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tShown\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");*/
            // loop through the result set
            while (rs.next()) {
                hasRows = true;

                keywordsId = rs.getInt(1);
                System.out.println("ID: "+ keywordsId +" ,URL: " + rs.getString(2) + " ,Keyword: " +  rs.getString(3) +
                        " ,Times shown: " + rs.getInt(4) +" ,Timestamp: " + rs.getString(5) );

                pstmt2.setInt(1,keywordsId);
                rs2 = pstmt2.executeQuery();
                if(rs2 != null) {
                    System.out.print("Negative Terms: ");
                    while (rs2.next()) {
                        System.out.print(rs2.getString(1) + "\t");

                    }
                    rs2.close();
                }else{
                    System.out.println("No Negative terms found");
                }
                System.out.println();
                pstmt3.setInt(1,keywordsId);
                rs3 = pstmt3.executeQuery();
                if(rs3 != null) {
                    System.out.print("Positive Terms: ");
                    while (rs3.next()) {
                        System.out.print(rs3.getString(1) + "\t");

                    }
                    rs3.close();
                }else{
                    System.out.println("No Positive terms found");
                }

                System.out.println();
                /*rs.getString("k.keyword")
                        rs.getInt("k.shown")
                        rs.getString("k.timestamp")  */


            }

            if(!hasRows)
                System.out.println("No Keywords were found between those dates.");

            rs.close();
            pstmt.close();
            pstmt2.close();
            pstmt3.close();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectNegativeImpressions(){
        String sql = "SELECT id,url,keyword,term,timestamp FROM negativeimpressions";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nNegative Impressions in Keyword searches");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tTerm\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("url")    + "\t\t\t\t"	 +
                        "\t\t" +rs.getString("keyword")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("term")         + "\t\t\t\t" +
                        "\t\t" +rs.getString("timestamp")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectPositiveImpressions(){
        String sql = "SELECT id,url,keyword,term,timestamp FROM positiveimpressions";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nPositive Impressions in Keyword searches");
            System.out.println("========================================================================================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tURL\t\t\t\t|\t\t\t\tKeyword\t\t\t\t|\t\t\t\tTerm\t\t\t\t|\t\t\t\tDate");
            System.out.println("========================================================================================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("url")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("keyword")    + "\t\t\t\t" +
                        "\t\t" +rs.getString("term")         + "\t\t\t\t" +
                        "\t\t" +rs.getString("timestamp")    + "\t\t\t\t"

                );
            }
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void selectNegativeTerms(){
        String sql = "SELECT id,term FROM negativeterms";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nNegative Terms");
            System.out.println("========================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tTerm\t\t\t\t");
            System.out.println("========================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("term")    + "\t\t\t\t"

                );
            }
            rs.close();
            stmt.close();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        /*finally{
            this.disconnect();
        }*/
    }

    public void selectPositiveTerms(){
        String sql = "SELECT id,term FROM positiveterms";

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            System.out.println("\nPositive Terms");
            System.out.println("========================================================================================");
            System.out.println("ID\t\t\t\t|\t\t\t\tTerm\t\t\t\t");
            System.out.println("========================================================================================");
            // loop through the result set
            while (rs.next()) {
                System.out.println(rs.getInt("id") +  "\t\t\t\t" +
                        "\t\t" +rs.getString("term")    + "\t\t\t\t"

                );
            }
            rs.close();
            stmt.close();
            this.disconnect();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        /*finally {
            this.disconnect();
        }*/
    }

    public String selectNegativeTermByID(int id){
        String sql = "SELECT term FROM negativeterms WHERE id=?";

        try {
            this.connect();
            PreparedStatement pstmt  = conn.prepareStatement(sql);
            pstmt.setInt(1,id);
            ResultSet rs    = pstmt.executeQuery();

            // loop through the result set
            while (rs.next()) {
                String negativeterm = rs.getString("term");
                rs.close();
                pstmt.close();
                this.disconnect();
                return negativeterm;
            }

            rs.close();
            pstmt.close();
            this.disconnect();
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String selectPositiveTermByID(int id){
        String sql = "SELECT term FROM positiveterms WHERE id=?";

        try {
            this.connect();
            PreparedStatement pstmt  = conn.prepareStatement(sql);
            pstmt.setInt(1,id);
            ResultSet rs    = pstmt.executeQuery();

            // loop through the result set
            while (rs.next()) {
                String positiveterm = rs.getString("term");
                rs.close();
                pstmt.close();
                this.disconnect();
                return positiveterm;
            }

            rs.close();
            pstmt.close();
            this.disconnect();
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int insertKeyword(Integer urlId,String keyword,int shown){
        String sql = "INSERT INTO keywords(url_id,keyword,shown,timestamp) VALUES(?,?,?,?)";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String ts = sdf.format(timestamp);

        /*lock1.lock();*/
        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, urlId);
            pstmt.setString(2, keyword);
            pstmt.setInt(3, shown);
            pstmt.setString(4, ts);
            int rowsAffected = pstmt.executeUpdate();
            if(rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                int id;
                if (rs.next()) {
                    id = rs.getInt(1);
                    rs.close();
                    pstmt.close();
                    this.disconnect();
                    return id;
                }
                else{
                    rs.close();
                    pstmt.close();
                    this.disconnect();
                    return -1;
                }
            }
            else{
                return -1;
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }
      /*  finally{
            lock1.unlock();
        }*/

    }

    public String selectUrlbyID(int id){
        String sql = "SELECT url FROM urls WHERE id=?";

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,id);
            ResultSet rs = pstmt.executeQuery();

            String url;

            if (rs.next()){
                url = rs.getString("url");
                rs.close();
                pstmt.close();
                this.disconnect();
                return url;
            }
            else {
                rs.close();
                pstmt.close();
                this.disconnect();
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            //this.disconnect();
            return null;
        }

    }

    public int deleteUrlbyID(int id){
        String sql = "DELETE FROM urls WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int deleteNegativebyID(int id){
        String sql = "DELETE FROM negativeterms WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int deletePositivebyID(int id){
        String sql = "DELETE FROM positiveterms WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int editUrlbyID(int id,String URL){
        String sql = "UPDATE urls SET url=? WHERE id=?";
        int rowsAffected;

        try {
            this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1,URL);
            pstmt.setInt(2,id);
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
            return rowsAffected;
            //rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return -1;
        }

    }

    public int searchPositiveImpressions(Integer urlid,int keywordsId,String extStr){  //void

        String impressionsArray[] = extStr.split(" ",10);   //Split the String into an array of strings seperated from blanks.
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String ts = sdf.format(timestamp);  //Make timestamp

        //Queries
        String sql = "SELECT id,term FROM positiveterms ";
        String sql2 = "INSERT INTO positiveimpressions(url_id,keywords_id,term_id,timestamp) VALUES(?,?,?,?)";

        /*lock2.lock();*/
        try {
            this.connect();
            //Positiveimpressions Table.
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);
            PreparedStatement pstmt = conn.prepareStatement(sql2);
            /*PreparedStatement temppstmt = conn.prepareStatement(tempsql2);*/

            // loop through the result set
            while (rs.next()) {
                for(String token : impressionsArray){
                    if(token.equalsIgnoreCase(rs.getString("term"))){
                        //PreparedStatement pstmt = conn.prepareStatement(sql2);
                        pstmt.setInt(1, urlid);
                        pstmt.setInt(2, keywordsId);
                        pstmt.setInt(3, rs.getInt("id"));
                        pstmt.setString(4, ts);
                        pstmt.executeUpdate();
                        int positiveimp = rs.getInt("id");
                        rs.close();
                        pstmt.close();
                        stmt.close();
                        this.disconnect();
                        return positiveimp;

                    }
                }

            }
            rs.close();
            pstmt.close();
            /*temppstmt.close();*/
            stmt.close();
            this.disconnect();
            return -1;

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        /*finally{
            lock2.unlock();
        }*/

    }

    public int searchNegativeImpressions(Integer urlid,int keywordsId,String extStr) {  //void

            String impressionsArray[] = extStr.split(" ",10);   //Split the String into an array of strings seperated from blanks.
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            String ts = sdf.format(timestamp);  //Make timestamp

            String sql3 = "SELECT id,term FROM negativeterms ";
            String sql4 = "INSERT INTO negativeimpressions(url_id,keywords_id,term_id,timestamp) VALUES(?,?,?,?)";

        try {
            this.connect();

            //Negativeimpressions Table.
            Statement stmt2 = conn.createStatement();
            ResultSet rs2 = stmt2.executeQuery(sql3);
            PreparedStatement pstmt2 = conn.prepareStatement(sql4);
            /*PreparedStatement temppstmt2 = conn.prepareStatement(tempsql4);*/

            while (rs2.next()) {
            for (String token : impressionsArray) {
                if (token.equalsIgnoreCase(rs2.getString("term"))) {
                //PreparedStatement pstmt2 = conn.prepareStatement(sql4);
                    pstmt2.setInt(1, urlid);
                    pstmt2.setInt(2, keywordsId);
                    pstmt2.setInt(3, rs2.getInt("id"));
                    pstmt2.setString(4, ts);
                    pstmt2.executeUpdate();
                    int negativeimp = rs2.getInt("id");
                    rs2.close();
                    pstmt2.close();
                    stmt2.close();
                    this.disconnect();
                    return negativeimp;
                }
            }

            }

            rs2.close();
            pstmt2.close();
            /* temppstmt2.close();*/
            stmt2.close();
            this.disconnect();
            return -1;
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }

    public void updateKeywordsCountById(int count,int id)  {
        try {
            this.connect();
            String sql = "UPDATE keywords SET shown=? WHERE id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,count);
            pstmt.setInt(2,id);
            pstmt.executeUpdate();
            pstmt.close();
            this.disconnect();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    public ArrayList<String> selectAllUrls(){

        ArrayList<String> urls = new ArrayList<String>();
        String sql = "SELECT url FROM urls";
        int i=0;

        try {
            this.connect();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql);

            while (rs.next()) {
                urls.add(rs.getString("url"));
                //urls[i] = rs.getString("url");

            }
            rs.close();
            this.disconnect();
            return urls;
        }
     catch (SQLException e) {
        System.out.println(e.getMessage());
        return null;
    }

    }

    public ArrayList<Integer> selectAllUrlsId() {
        ArrayList<Integer> urlsIds = new ArrayList<Integer>();
        String sql = "SELECT id FROM urls";
        int i=0;

        try {
            this.connect();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(sql);

            while (rs.next()) {
                urlsIds.add(rs.getInt("id"));
                //urls[i] = rs.getString("url");

            }
            rs.close();
            this.disconnect();
            return urlsIds;
        }
        catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }

    }


}

