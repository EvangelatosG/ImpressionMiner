import org.jsoup.Jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.CASE_INSENSITIVE;

public class IMThread implements Runnable{
    private String name;
    /* private Thread t; */
    private Integer selectedUrlId;
    private ArrayList<String> keyArrayList;
   /* private Lock dbLock = new ReentrantLock(); // ReentrantLock implements the Lock interface
    private Lock dbLock2 = new ReentrantLock();*/
   // static  Lock lock = new ReentrantLock();
   private static ReentrantLock lock = new ReentrantLock(); //If not static, it gives error ([SQLITE_BUSY] Database is locked)

    //Constructor
    public IMThread(String threadName, Integer urlid, ArrayList<String> keys){
        this.name = threadName;
        this.selectedUrlId = urlid;
        this.keyArrayList = keys;
        /*t = new Thread(this,name);
        t.start();*/
}

//Run method of the Thread
    public void run() {
        //System.out.println(Thread.currentThread().getName());   //Print thread name.
       /* ReentrantLock lock = new ReentrantLock(); //Lock lock*/
        //DBConnection db4 = new DBConnection();
        if (Thread.interrupted()) { //Check if thread is interrupted.
            System.out.println(Thread.currentThread().getName() + " is interrupted");
            return;
        }

        String stringHtml;
        DBConnection db4 = DBConnection.getInstance();

        lock.lock();    //Lock area for multithreading.Only 1 thread can enter here each time.Without this lock, [SQLITE_BUSY]-database is locked errors occurs.
        try {
            //Search the URL for the keywords
            stringHtml = Jsoup.connect(db4.selectUrlbyID(selectedUrlId)).timeout(0).get().text();   //stringHtml = Jsoup.connect(selectedUrl).get().html();
      /*  } catch (IllegalArgumentException e) {
           e.printStackTrace();
            return;
        } catch (IOException e) {
         e.printStackTrace();
            return;
        }*/

      /*  *//*==========INTERRUPT=========*//*
        if (Thread.interrupted()) {
            System.out.println(Thread.currentThread().getName());
            return;
        }*/

        int k = 0;
        int count = 0;
        String impressionsStr;  // String with 100 characters search for positive-negative impressions .
        //String[] impressionsArray;  //String Array that will store the impressions
        int keywordsInsertId;
        ArrayList<Integer> negativeTermsId= new ArrayList<Integer>();
        ArrayList<Integer> positiveTermsId= new ArrayList<Integer>();

        int negid, posid;

       /* *//*==========INTERRUPT=========*//*
        if (Thread.interrupted()) {
            System.out.println(Thread.currentThread().getName());
            return;
        }*/

        //lock.lock();    //Lock area for multithreading.Only 1 thread can enter here each time.Without this lock, [SQLITE_BUSY]-database is locked errors occurs.
        //try{

            //Regular expressions
            for (String keyword : keyArrayList) {

                if (Thread.interrupted()) { //Check if thread is interrupted.
                    System.out.println(Thread.currentThread().getName() + " is interrupted");
                    return;
                }

                Pattern ptrn = Pattern.compile(keyword, CASE_INSENSITIVE); // Pattern ptrn = Pattern.compile(keyword);
                Matcher mtchr = ptrn.matcher(stringHtml);
                keywordsInsertId = db4.insertKeyword(selectedUrlId, keyword, 0); //Inserts a new row in keywords table and returns its id .

                while (mtchr.find(k)) { //Resets this matcher and then attempts to find the next subsequence of the input sequence that matches the pattern, starting at the specified index.
                    count++;    //System.out.print(count + "  ");
                    k = mtchr.start() + 1;  //Returns the start index of the previous match(start()).

                    //Call the function for good and bad impressions HERE !!!
                    if (k > 50 && stringHtml.length() > k + 50) {
                        impressionsStr = stringHtml.substring(k - 50, k + 50);
                    } else if (k < 50 && stringHtml.length() > k + 50) {
                        impressionsStr = stringHtml.substring(0, k + 50);
                    } else if (k > 50 && stringHtml.length() < k + 50) {
                        impressionsStr = stringHtml.substring(k - 50, stringHtml.length());
                    } else {
                        impressionsStr = stringHtml.substring(0, stringHtml.length());
                    }
                    /**********Testing**********/
                    System.out.println("\nURL : "+ db4.selectUrlbyID(selectedUrlId) +" Keyword : "+ keyword +" Index of keyword : "+ k);
                    System.out.println("String for term search : " + impressionsStr);
                    /**********Testing**********/

                    negid = db4.searchNegativeImpressions(selectedUrlId, keywordsInsertId, impressionsStr);
                    posid = db4.searchPositiveImpressions(selectedUrlId, keywordsInsertId, impressionsStr);
                    /*db4.searchImpressions(selectedUrlId, keywordsInsertId, impressionsStr);  //Search impression terms for every keyword*/
                    if(negid != -1)
                        negativeTermsId.add(negid);
                    if(posid != -1)
                        positiveTermsId.add(posid);
                }

                if(count != 0){
                    db4.updateKeywordsCountById(count,keywordsInsertId);
                    //db4.insertKeyword(selectedUrl, keyword, count);    //Insert search result into keywords table.
                }
                /*db4.insertTempKeyword(selectedUrlId, keyword, count);*/

                System.out.println("\n==========Keywords Count==========");
                System.out.println("URL: "+ db4.selectUrlbyID(selectedUrlId)+" ,Keyword: "+keyword+" ,Times Shown: "+count);

                System.out.println("==========Negative Terms==========");
                if(negativeTermsId.isEmpty()){
                    System.out.println("No negative terms were found.");
                }
                else{
                    for(int nterm : negativeTermsId){
                        System.out.println("Negative term id:" + nterm);
                        System.out.println("URL: "+db4.selectUrlbyID(selectedUrlId)+" Keyword: "+keyword+" Negative term: "+db4.selectNegativeTermByID(nterm));
                    }
                }

                System.out.println("==========Positive Terms==========");
                if(positiveTermsId.isEmpty()){
                    System.out.println("No positive terms were found.");
                }
                else{
                    for(int pterm : positiveTermsId){
                        System.out.println("Positive term id:" + pterm);
                        System.out.println("URL: "+db4.selectUrlbyID(selectedUrlId)+" Keyword: "+keyword+" Positive term: "+db4.selectPositiveTermByID(pterm));
                    }
                }

                k = 0;
                count = 0;
                negativeTermsId.clear();
                positiveTermsId.clear();
                /*sleep(100);*/

               /* *//*==========INTERRUPT=========*//*
                if (Thread.interrupted()) {
                    System.out.println("Thread " + Thread.currentThread().getName() + "is interrupted");
                    return;
                }*/

            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return;
        } catch (IOException e) {
            e.printStackTrace();
            return;
        } catch(Exception e){
            e.printStackTrace();
            return;
        }
        finally{
            lock.unlock();  //Unlock area.
        }
        /*catch(InterruptedException ex){
            System.out.println(Thread.currentThread().getName()+" is interrupted");
            //ex.printStackTrace();
        }*/
    }
}
